
const userForm = document.getElementById("userForm");
const userList = document.getElementById("userList");
const statusMessage = document.getElementById("status");
const userIdInput = document.getElementById("userId");
const cancelEdit = document.getElementById("cancelEdit");

async function loadUsers() {
    try {
        const response = await fetch("/api/users");

        if (!response.ok) {
            throw new Error("Could not load users");
        }

        const users = await response.json();
        userList.replaceChildren();

        if (users.length === 0) {
            userList.textContent = "No users registered yet.";
            return;
        }

        users.forEach(user => {
            const card = document.createElement("div");
            card.className = "user-card";

            const details = document.createElement("p");
            details.textContent =
                `#${user.id} | ${user.name} | ${user.email} | Age: ${user.age} | ${user.gender}`;

            const editButton = document.createElement("button");
            editButton.textContent = "Edit";
            editButton.addEventListener("click", () => {
                userIdInput.value = user.id;
                document.getElementById("name").value = user.name;
                document.getElementById("email").value = user.email;
                document.getElementById("age").value = user.age;
                document.getElementById("gender").value = user.gender;

                document.getElementById("formTitle").textContent =
                    "Edit User";
                cancelEdit.hidden = false;
                userForm.scrollIntoView({ behavior: "smooth" });
            });

            const deleteButton = document.createElement("button");
            deleteButton.textContent = "Delete";
            deleteButton.className = "delete-btn";

            deleteButton.addEventListener("click", async () => {
                if (!confirm(`Delete ${user.name}?`)) return;

                try {
                    const result = await fetch(
                        `/api/users/${user.id}`,
                        { method: "DELETE" }
                    );

                    const data = await result.json();

                    if (!result.ok) {
                        throw new Error(data.message || "Delete failed");
                    }

                    statusMessage.textContent = data.message;
                    await loadUsers();
                } catch (error) {
                    statusMessage.textContent = error.message;
                }
            });

            card.append(details, editButton, deleteButton);
            userList.appendChild(card);
        });
    } catch (error) {
        userList.textContent = "Error loading users: " + error.message;
    }
}

userForm.addEventListener("submit", async event => {
    event.preventDefault();

    const id = userIdInput.value;

    const user = {
        name: document.getElementById("name").value.trim(),
        email: document.getElementById("email").value.trim(),
        age: Number(document.getElementById("age").value),
        gender: document.getElementById("gender").value
    };

    try {
        const response = await fetch(
            id ? `/api/users/${id}` : "/api/users",
            {
                method: id ? "PUT" : "POST",
                headers: { "Content-Type": "application/json" },
                body: JSON.stringify(user)
            }
        );

        const data = await response.json();

        if (!response.ok) {
            throw new Error(data.message || "Request failed");
        }

        statusMessage.textContent = data.message;
        userForm.reset();
        userIdInput.value = "";
        document.getElementById("formTitle").textContent = "Add New User";
        cancelEdit.hidden = true;

        await loadUsers();
    } catch (error) {
        statusMessage.textContent = error.message;
    }
});

cancelEdit.addEventListener("click", () => {
    userForm.reset();
    userIdInput.value = "";
    document.getElementById("formTitle").textContent = "Add New User";
    cancelEdit.hidden = true;
});

loadUsers();
