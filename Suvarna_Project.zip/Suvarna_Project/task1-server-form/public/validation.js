
document.addEventListener("DOMContentLoaded", () => {
    const password = document.getElementById("password");
    const confirmPassword = document.getElementById("confirmPassword");
    const form = document.getElementById("registrationForm");

    if (!password || !confirmPassword || !form) {
        console.error("Check the form and input element IDs.");
        return;
    }

    const strengthMessage = document.getElementById("passwordStrength");
    const errorMessage = document.getElementById("passwordError");

    // Password strength checker
    password.addEventListener("input", () => {
        const value = password.value;
        let score = 0;

        if (value.length >= 8) score++;
        if (/[A-Z]/.test(value)) score++;
        if (/[a-z]/.test(value)) score++;
        if (/[0-9]/.test(value)) score++;
        if (/[^A-Za-z0-9]/.test(value)) score++;

        const levels = ["Very weak", "Weak", "Fair", "Good", "Strong"];

        if (strengthMessage) {
            strengthMessage.textContent =
                value.length === 0
                    ? ""
                    : "Password strength: " + levels[Math.max(0, score - 1)];
        }
    });

    // Username character counter
    const username = document.getElementById("username");
    const usernameCount = document.getElementById("usernameCount");

    if (username && usernameCount) {
        username.addEventListener("input", () => {
            const count = username.value.length;

            usernameCount.textContent = `${count} characters`;
            usernameCount.style.color = count < 3 ? "red" : "green";
        });
    }

    // Form validation
    form.addEventListener("submit", (event) => {
        const value = password.value;

        const strongPassword =
            value.length >= 8 &&
            /[A-Z]/.test(value) &&
            /[a-z]/.test(value) &&
            /[0-9]/.test(value) &&
            /[^A-Za-z0-9]/.test(value);

        if (!strongPassword) {
            event.preventDefault();

            if (errorMessage) {
                errorMessage.textContent =
                    "Use at least 8 characters, including uppercase, lowercase, a number, and a special character.";
            }

            password.focus();
            return;
        }

        if (password.value !== confirmPassword.value) {
            event.preventDefault();

            if (errorMessage) {
                errorMessage.textContent = "Passwords do not match.";
            }

            confirmPassword.focus();
            return;
        }

        if (errorMessage) {
            errorMessage.textContent = "";
        }
    });
});
