
const app = document.getElementById("app");

const pages = {
    "#home": `
        <h2>Home</h2>
        <p>Welcome to your dashboard!</p>
    `,
    "#profile": `
        <h2>Profile</h2>
        <p>View your profile information here.</p>
    `,
    "#settings": `
        <h2>Settings</h2>
        <p>Manage your application settings here.</p>
    `
};

function renderPage() {
    const page = pages[window.location.hash] || pages["#home"];
    app.innerHTML = page;
}

window.addEventListener("hashchange", renderPage);

renderPage();
