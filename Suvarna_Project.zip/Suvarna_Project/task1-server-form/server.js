
require("dotenv").config();

const express = require("express");
const bcrypt = require("bcrypt");
const session = require("express-session");
const db = require("./db");

const app = express();
const PORT = 3000;

if (!process.env.SESSION_SECRET) {
    throw new Error("SESSION_SECRET is missing from your .env file.");
}

app.set("view engine", "ejs");

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static("public"));

app.use(session({
    secret: process.env.SESSION_SECRET,
    resave: false,
    saveUninitialized: false,
    cookie: {
        httpOnly: true,
        sameSite: "lax",
        secure: false, // Local HTTP development only
        maxAge: 60 * 60 * 1000
    }
}));

// Require login for protected pages and APIs.
function requireAuth(req, res, next) {
    if (!req.session.user) {
        if (req.path.startsWith("/api/")) {
            return res.status(401).json({
                message: "Please log in first."
            });
        }

        return res.redirect("/login");
    }

    next();
}

// Registration page
app.get("/", (req, res) => {
    res.render("index", { message: "" });
});

// Register a new user
app.post("/submit", async (req, res) => {
    const { name, email, age, gender, password } = req.body;
    const cleanName = typeof name === "string" ? name.trim() : "";
    const cleanEmail = typeof email === "string"
        ? email.trim().toLowerCase()
        : "";
    const numericAge = Number(age);

    if (!cleanName || !cleanEmail || !gender || typeof gender !== "string") {
        return res.status(400).render("index", {
            message: "Please fill in all required fields."
        });
    }

    if (!Number.isInteger(numericAge) || numericAge < 18) {
        return res.status(400).render("index", {
            message: "Age must be 18 or older."
        });
    }

    if (typeof password !== "string" || password.length < 8) {
        return res.status(400).render("index", {
            message: "Password must contain at least 8 characters."
        });
    }

    try {
        const passwordHash = await bcrypt.hash(password, 12);

        await db.execute(
            `INSERT INTO users (name, email, password_hash, age, gender)
             VALUES (?, ?, ?, ?, ?)`,
            [cleanName, cleanEmail, passwordHash, numericAge, gender.trim()]
        );

        return res.render("index", {
            message: "Registration successful! You can now log in."
        });
    } catch (error) {
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).render("index", {
                message: "That email is already registered. Please log in."
            });
        }

        console.error("Registration error:", error.message);
        return res.status(500).render("index", {
            message: "Registration failed. Please try again."
        });
    }
});

// Login page
app.get("/login", (req, res) => {
    if (req.session.user) {
        return res.redirect("/dashboard");
    }

    res.render("login", { message: "" });
});

// Log in with email and password
app.post("/login", async (req, res) => {
    const email = typeof req.body.email === "string"
        ? req.body.email.trim().toLowerCase()
        : "";
    const password = req.body.password;

    if (!email || typeof password !== "string" || !password) {
        return res.status(400).render("login", {
            message: "Enter your email and password."
        });
    }

    try {
        const [rows] = await db.execute(
            "SELECT id, name, email, password_hash FROM users WHERE email = ?",
            [email]
        );

        if (
            rows.length === 0 ||
            !(await bcrypt.compare(password, rows[0].password_hash))
        ) {
            return res.status(401).render("login", {
                message: "Invalid email or password."
            });
        }

        const user = rows[0];

        // Regenerate the session after successful authentication.
        req.session.regenerate((error) => {
            if (error) {
                console.error("Session error:", error.message);
                return res.status(500).render("login", {
                    message: "Login failed. Please try again."
                });
            }

            req.session.user = {
                id: user.id,
                name: user.name,
                email: user.email
            };

            req.session.save((saveError) => {
                if (saveError) {
                    console.error("Session save error:", saveError.message);
                    return res.status(500).render("login", {
                        message: "Login failed. Please try again."
                    });
                }

                res.redirect("/dashboard");
            });
        });
    } catch (error) {
        console.error("Login error:", error.message);
        res.status(500).render("login", {
            message: "Something went wrong. Please try again."
        });
    }
});

// Log out
app.post("/logout", requireAuth, (req, res, next) => {
    req.session.destroy((error) => {
        if (error) {
            return next(error);
        }

        res.clearCookie("connect.sid");
        res.redirect("/login");
    });
});

// Protected dashboard
app.get("/dashboard", requireAuth, (req, res) => {
    res.render("dashboard", { user: req.session.user });
});

// Protected user list page
app.get("/users", requireAuth, (req, res) => {
    res.render("users");
});

// READ: Get all users (never return password hashes)
app.get("/api/users", requireAuth, async (req, res) => {
    try {
        const [rows] = await db.execute(
            `SELECT id, name, email, age, gender, created_at
             FROM users ORDER BY id DESC`
        );

        res.json(rows);
    } catch (error) {
        console.error("Read users error:", error.message);
        res.status(500).json({ message: "Could not retrieve users." });
    }
});

// READ: Get one user by ID
app.get("/api/users/:id", requireAuth, async (req, res) => {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ message: "Invalid user ID." });
    }

    try {
        const [rows] = await db.execute(
            `SELECT id, name, email, age, gender, created_at
             FROM users WHERE id = ?`,
            [id]
        );

        if (rows.length === 0) {
            return res.status(404).json({ message: "User not found." });
        }

        res.json(rows[0]);
    } catch (error) {
        console.error("Read user error:", error.message);
        res.status(500).json({ message: "Could not retrieve user." });
    }
});

// CREATE: Add a user through the API (password is required)
app.post("/api/users", requireAuth, async (req, res) => {
    const { name, email, age, gender, password } = req.body;
    const cleanName = typeof name === "string" ? name.trim() : "";
    const cleanEmail = typeof email === "string"
        ? email.trim().toLowerCase()
        : "";
    const numericAge = Number(age);

    if (
        !cleanName ||
        !cleanEmail ||
        !Number.isInteger(numericAge) ||
        numericAge < 18 ||
        typeof gender !== "string" ||
        !gender.trim() ||
        typeof password !== "string" ||
        password.length < 8
    ) {
        return res.status(400).json({
            message: "Enter a valid name, email, age (18+), gender, and password (8+ characters)."
        });
    }

    try {
        const passwordHash = await bcrypt.hash(password, 12);

        const [result] = await db.execute(
            `INSERT INTO users (name, email, password_hash, age, gender)
             VALUES (?, ?, ?, ?, ?)`,
            [cleanName, cleanEmail, passwordHash, numericAge, gender.trim()]
        );

        res.status(201).json({
            message: "User created successfully.",
            user: {
                id: result.insertId,
                name: cleanName,
                email: cleanEmail,
                age: numericAge,
                gender: gender.trim()
            }
        });
    } catch (error) {
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "That email is already registered."
            });
        }

        console.error("Create user error:", error.message);
        res.status(500).json({ message: "Could not create user." });
    }
});

// UPDATE: Edit a user's details
app.put("/api/users/:id", requireAuth, async (req, res) => {
    const id = Number(req.params.id);
    const { name, email, age, gender } = req.body;
    const cleanName = typeof name === "string" ? name.trim() : "";
    const cleanEmail = typeof email === "string"
        ? email.trim().toLowerCase()
        : "";
    const numericAge = Number(age);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ message: "Invalid user ID." });
    }

    if (
        !cleanName ||
        !cleanEmail ||
        !Number.isInteger(numericAge) ||
        numericAge < 18 ||
        typeof gender !== "string" ||
        !gender.trim()
    ) {
        return res.status(400).json({
            message: "Enter valid name, email, age (18+), and gender."
        });
    }

    try {
        const [result] = await db.execute(
            `UPDATE users
             SET name = ?, email = ?, age = ?, gender = ?
             WHERE id = ?`,
            [cleanName, cleanEmail, numericAge, gender.trim(), id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "User not found." });
        }

        res.json({
            message: "User updated successfully.",
            user: {
                id,
                name: cleanName,
                email: cleanEmail,
                age: numericAge,
                gender: gender.trim()
            }
        });
    } catch (error) {
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                message: "That email is already registered to another user."
            });
        }

        console.error("Update user error:", error.message);
        res.status(500).json({ message: "Could not update user." });
    }
});

// DELETE: Remove a user
app.delete("/api/users/:id", requireAuth, async (req, res) => {
    const id = Number(req.params.id);

    if (!Number.isInteger(id) || id < 1) {
        return res.status(400).json({ message: "Invalid user ID." });
    }

    try {
        const [result] = await db.execute(
            "DELETE FROM users WHERE id = ?",
            [id]
        );

        if (result.affectedRows === 0) {
            return res.status(404).json({ message: "User not found." });
        }

        res.json({ message: "User deleted successfully." });
    } catch (error) {
        console.error("Delete user error:", error.message);
        res.status(500).json({ message: "Could not delete user." });
    }
});

app.listen(PORT, () => {
    console.log(`Server running at http://localhost:${PORT}`);
});
